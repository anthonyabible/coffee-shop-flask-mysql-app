# -*- encoding: utf-8 -*-
"""
Routes for Mill Mountain Coffee Project
"""

from flask import (
    render_template,
    request,
    redirect,
    url_for,
    flash,
    session,
)
from app import app
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import os
import json
import pymysql

# Modern OpenAI API
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()
client = OpenAI()


# ---------------------------------------------------------
# DATABASE CONNECTION
# ---------------------------------------------------------
def get_db():
    return pymysql.connect(
        host="office.scholars.bond",
        user="bit4444group13",
        password="aGX6Cb5Z61MLIf7@",
        database="bit4444group13",
        port=3309,
        cursorclass=pymysql.cursors.DictCursor,
        connect_timeout=10,
    )


# ---------------------------------------------------------
# HELPERS — AUTHENTICATION
# ---------------------------------------------------------
def login_required(f):
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_email" not in session:
            flash("Please login first.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_email" not in session or session.get("user_role") != "admin":
            flash("Admins only.", "danger")
            return redirect(url_for("menu"))
        return f(*args, **kwargs)
    return wrapper


# ---------------------------------------------------------
# UPLOAD FOLDER
# ---------------------------------------------------------
UPLOAD_FOLDER = os.path.join(app.root_path, "static", "uploads")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ---------------------------------------------------------
# CART INITIALIZATION
# ---------------------------------------------------------
def initialize_cart():
    if "cart" not in session:
        session["cart"] = []
    if "subtotal" not in session:
        session["subtotal"] = 0.0


# ---------------------------------------------------------
# HOME / MENU PAGE
# ---------------------------------------------------------
@app.route("/")
def menu():
    initialize_cart()

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM Product WHERE ActiveFlag = 1")
    products = cur.fetchall()
    conn.close()

    return render_template(
        "menu.html",
        products=products,
        coffee_categories=["Coffee"],
        tea_categories=["Tea"],
        specialty_categories=["Specialty"],
        cart=session.get("cart", []),
        subtotal=session.get("subtotal", 0.0),
    )


# ---------------------------------------------------------
# LOGIN
# ---------------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM UserProfile WHERE Email=%s", (email,))
        user = cur.fetchone()
        conn.close()

        if not user:
            flash("Email not found.", "danger")
            return redirect(url_for("login"))

        # Password check (UPassword column)
        if not check_password_hash(user["UPassword"], password):
            flash("Incorrect password.", "danger")
            return redirect(url_for("login"))

        # Store session values
        session["user_email"] = user["Email"]
        session["user_name"] = user["ContactFirstName"]
        session["user_role"] = user["UserType"]   # Admin / Merchant / Customer

        flash("Successfully logged in!", "success")
        return redirect(url_for("menu"))

    return render_template("login.html")



# ---------------------------------------------------------
# LOGOUT
# ---------------------------------------------------------
@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for("menu"))


# ---------------------------------------------------------
# SIGNUP
# ---------------------------------------------------------
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        first = request.form.get("first")
        last = request.form.get("last")
        phone = request.form.get("phone")
        business = request.form.get("business")

        # Hash password
        hashed = generate_password_hash(password)

        conn = get_db()
        cur = conn.cursor()

        try:
            cur.execute("""
                INSERT INTO UserProfile
                (Email, UserType, ContactFirstName, ContactLastName, UPassword,
                 Phone, BusinessName, ActiveFlag)
                VALUES (%s, 'Customer', %s, %s, %s, %s, %s, 1)
            """, (email, first, last, hashed, phone, business))

            conn.commit()
            flash("Account created! Please log in.", "success")
            return redirect(url_for("login"))

        except Exception as e:
            conn.rollback()
            print("SIGNUP ERROR:", e)
            flash("Error creating account. Email may already exist.", "danger")

        finally:
            conn.close()

    return render_template("signup.html")


# ---------------------------------------------------------
# PROFILE
# ---------------------------------------------------------
@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    email = session["user_email"]

    conn = get_db()
    cur = conn.cursor()

    if request.method == "POST":
        first = request.form["first"]
        last = request.form["last"]
        phone = request.form["phone"]
        business = request.form["business"]
        website = request.form["website"]

        cur.execute("""
            UPDATE UserProfile
            SET ContactFirstName=%s,
                ContactLastName=%s,
                Phone=%s,
                BusinessName=%s,
                Website=%s
            WHERE Email=%s
        """, (first, last, phone, business, website, email))

        conn.commit()
        conn.close()

        session["user_name"] = first
        flash("Profile updated!", "success")
        return redirect(url_for("profile"))

    cur.execute("SELECT * FROM UserProfile WHERE Email=%s", (email,))
    user = cur.fetchone()
    conn.close()

    return render_template("profile.html", user=user)



# ---------------------------------------------------------
# ADMIN DASHBOARD
# ---------------------------------------------------------
@app.route("/admin")
@admin_required
def admin_dashboard():
    return render_template("admin.html")


# ---------------------------------------------------------
# ADMIN USER ANALYTICS
# ---------------------------------------------------------
@app.route("/admin_users_analytics")
@admin_required
def admin_users_analytics():

    conn = get_db()
    cur = conn.cursor()

    # Count users by UserType (Admin, Merchant, Customer)
    cur.execute("""
        SELECT UserType AS label, COUNT(*) AS value
        FROM UserProfile
        GROUP BY UserType
    """)
    rows = cur.fetchall()
    conn.close()

    # Convert for FusionCharts
    chart_data = []
    for r in rows:
        chart_data.append({
            "label": r["label"],
            "value": int(r["value"])
        })

    return render_template("admin_users_analytics.html", chart_data=chart_data)


# ---------------------------------------------------------
# EVERYTHING BELOW THIS POINT IS YOUR ORIGINAL CODE
# (No changes were made to checkout, orders, inventory, analytics)
# ---------------------------------------------------------

# ADD TO CART
@app.route("/add_to_cart", methods=["POST"])
def add_to_cart():
    initialize_cart()

    pid = request.form.get("pid")
    qty = int(request.form.get("qty", 1))

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM Product WHERE PID=%s", (pid,))
    product = cur.fetchone()
    conn.close()

    if not product:
        flash("Product not found.", "danger")
        return redirect(url_for("menu"))

    name = product["PName"]
    price = float(product["UnitPrice"])

    cart = session["cart"]

    existing = next((i for i in cart if str(i["pid"]) == str(pid)), None)
    if existing:
        existing["qty"] += qty
        existing["total"] = existing["qty"] * price
    else:
        cart.append({"pid": pid, "name": name, "qty": qty, "price": price, "total": qty * price})

    session["subtotal"] = sum(i["total"] for i in cart)

    flash(f"Added {qty} × {name} to cart.", "success")
    return redirect(url_for("menu"))


# CHECKOUT
@app.route("/checkout")
def checkout():
    initialize_cart()
    return render_template("checkout.html", cart=session["cart"], subtotal=session["subtotal"])


# PROCESS CHECKOUT
@app.route("/process_checkout", methods=["POST"])
def process_checkout():
    initialize_cart()

    cart = session["cart"]
    if not cart:
        flash("Cart is empty.", "warning")
        return redirect(url_for("checkout"))

    email = request.form.get("customer_email")
    subtotal = session["subtotal"]
    total_qty = sum(i["qty"] for i in cart)

    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO Orders (MerchantEmail, BuyerEmail, TotalQuantity, TotalAmount, OrderStatus)
        VALUES (%s, %s, %s, %s, %s)
    """, ("merchant@millmountain.com", email, total_qty, subtotal, "Pending"))

    oid = cur.lastrowid

    for item in cart:
        cur.execute("""
            INSERT INTO OrderDetail (OID, PID, Quantity, Amount)
            VALUES (%s, %s, %s, %s)
        """, (oid, item["pid"], item["qty"], item["total"]))

        cur.execute("UPDATE Product SET Quantity = Quantity - %s WHERE PID=%s",
                    (item["qty"], item["pid"]))

    conn.commit()
    conn.close()

    session["cart"] = []
    session["subtotal"] = 0

    return redirect(url_for("order_confirmation", oid=oid))


# ORDER CONFIRMATION
@app.route("/order_confirmation/<int:oid>")
def order_confirmation(oid):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT * FROM Orders WHERE OID=%s", (oid,))
    order = cur.fetchone()

    cur.execute("""
        SELECT OD.*, P.PName
        FROM OrderDetail OD
        JOIN Product P ON OD.PID=P.PID
        WHERE OD.OID=%s
    """, (oid,))
    items = cur.fetchall()

    conn.close()

    return render_template("order_confirmation.html", order=order, items=items)


# VIEW ORDERS
@app.route("/myorders")
def myorders():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM Orders ORDER BY OID DESC")
    orders = cur.fetchall()
    conn.close()
    return render_template("myorders.html", orders=orders)


# EDIT ORDER
@app.route("/order/<int:oid>")
def edit_order(oid):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT * FROM Orders WHERE OID=%s", (oid,))
    order = cur.fetchone()

    cur.execute("""
        SELECT OD.*, P.PName
        FROM OrderDetail OD
        JOIN Product P ON OD.PID=P.PID
        WHERE OD.OID=%s
    """, (oid,))
    items = cur.fetchall()

    conn.close()

    return render_template("edit_order.html", order=order, items=items)


# UPDATE ORDER
@app.route("/order/<int:oid>/update", methods=["POST"])
def update_order(oid):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT * FROM OrderDetail WHERE OID=%s", (oid,))
    items = cur.fetchall()

    for item in items:
        pid = item["PID"]
        new_qty = int(request.form.get(f"qty_{pid}", item["Quantity"]))

        cur.execute("SELECT UnitPrice FROM Product WHERE PID=%s", (pid,))
        price = float(cur.fetchone()["UnitPrice"])
        new_amt = new_qty * price

        cur.execute("""
            UPDATE OrderDetail
            SET Quantity=%s, Amount=%s
            WHERE OID=%s AND PID=%s
        """, (new_qty, new_amt, oid, pid))

    cur.execute("SELECT SUM(Amount) AS total FROM OrderDetail WHERE OID=%s", (oid,))
    total = cur.fetchone()["total"]

    cur.execute("UPDATE Orders SET TotalAmount=%s WHERE OID=%s", (total, oid))
    conn.commit()
    conn.close()

    flash("Order updated!", "success")
    return redirect(url_for("edit_order", oid=oid))


# CANCEL ORDER
@app.route("/order/<int:oid>/cancel")
def cancel_order(oid):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT * FROM OrderDetail WHERE OID=%s", (oid,))
    rows = cur.fetchall()

    for r in rows:
        cur.execute("UPDATE Product SET Quantity = Quantity + %s WHERE PID=%s",
                    (r["Quantity"], r["PID"]))

    cur.execute("UPDATE Orders SET OrderStatus='Cancelled' WHERE OID=%s", (oid,))
    conn.commit()
    conn.close()

    flash("Cancelled.", "info")
    return redirect(url_for("myorders"))


# ORDER SEARCH
@app.route("/ordersearch")
def ordersearch():
    from_date = request.args.get("from")
    to_date = request.args.get("to")
    oid = request.args.get("oid")
    pname = request.args.get("pname")

    sql = """
        SELECT DISTINCT O.OID, O.OrderDate, O.TotalQuantity, O.TotalAmount, O.OrderStatus
        FROM Orders O
        LEFT JOIN OrderDetail OD ON O.OID=OD.OID
        LEFT JOIN Product P ON OD.PID=P.PID
        WHERE 1=1
    """
    params = []

    if from_date:
        sql += " AND O.OrderDate >= %s"
        params.append(from_date)
    if to_date:
        sql += " AND O.OrderDate <= %s"
        params.append(to_date)
    if oid:
        sql += " AND O.OID LIKE %s"
        params.append(f"%{oid}%")
    if pname:
        sql += " AND P.PName LIKE %s"
        params.append(f"%{pname}%")

    conn = get_db()
    cur = conn.cursor()
    cur.execute(sql, params)
    results = cur.fetchall()
    conn.close()

    return render_template("ordersearch.html", results=results)


# ANALYTICS DASHBOARD
@app.route("/analytics")
def analytics():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        SELECT COUNT(*) AS TotalOrders,
               COALESCE(SUM(TotalAmount),0) AS TotalRevenue,
               COALESCE(SUM(TotalQuantity),0) AS TotalItems
        FROM Orders
    """)
    summary = cur.fetchone()

    cur.execute("""
        SELECT DATE(OrderDate) AS d, SUM(TotalAmount) AS a
        FROM Orders
        GROUP BY DATE(OrderDate)
        ORDER BY d
    """)
    rows = cur.fetchall()
    sales = [{"label": str(r["d"]), "value": float(r["a"])} for r in rows]

    cur.execute("""
        SELECT P.PCategory, SUM(OD.Amount) AS rev
        FROM OrderDetail OD
        JOIN Product P ON OD.PID=P.PID
        GROUP BY P.PCategory
    """)
    rows = cur.fetchall()
    rev = [{"label": r["PCategory"], "value": float(r["rev"])} for r in rows]

    cur.execute("""
        SELECT P.PName, SUM(OD.Quantity) AS qty
        FROM OrderDetail OD
        JOIN Product P ON OD.PID=P.PID
        GROUP BY P.PName
        ORDER BY qty DESC
        LIMIT 5
    """)
    rows = cur.fetchall()
    best = [{"label": r["PName"], "value": int(r["qty"])} for r in rows]

    cur.execute("SELECT PName, Quantity FROM Product WHERE Quantity <= 20")
    rows = cur.fetchall()
    low = [{"label": r["PName"], "value": int(r["Quantity"])} for r in rows]

    conn.close()

    return render_template("analytics.html",
                           total_orders=summary["TotalOrders"],
                           total_revenue=summary["TotalRevenue"],
                           total_items=summary["TotalItems"],
                           sales_by_day=json.dumps(sales),
                           revenue_by_category=json.dumps(rev),
                           best_sellers=json.dumps(best),
                           low_inventory=json.dumps(low))


# ---------------------------------------------------------
# INVENTORY CRUD
# ---------------------------------------------------------
@app.route("/add-product.html", methods=["GET", "POST"])
def add_product():
    if request.method == "POST":

        name = request.form["product_name"]
        category = request.form["category"]
        price = request.form["price"]
        qty = request.form["quantity"]
        desc = request.form["description"]

        file = request.files.get("image")
        image_path = None

        if file and file.filename:
            filename = secure_filename(file.filename)
            image_path = f"uploads/{filename}"
            file.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))

        conn = get_db()
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO Product (PName, PDescription, UnitPrice, Quantity, PCategory, Image, ActiveFlag)
            VALUES (%s,%s,%s,%s,%s,%s,1)
        """, (name, desc, price, qty, category, image_path))

        conn.commit()
        conn.close()

        flash("Product added!", "success")
        return redirect(url_for("inventory_list"))

    return render_template("add-product.html")


@app.route("/inventory-list.html")
def inventory_list():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM Product WHERE ActiveFlag=1")
    products = cur.fetchall()
    conn.close()

    return render_template("inventory-list.html", products=products)


@app.route("/edit-product/<int:pid>", methods=["GET", "POST"])
def edit_product(pid):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM Product WHERE PID=%s", (pid,))
    product = cur.fetchone()

    if not product:
        conn.close()
        flash("Product not found.", "danger")
        return redirect(url_for("inventory_list"))

    if request.method == "POST":
        name = request.form["product_name"]
        category = request.form["category"]
        price = request.form["price"]
        qty = request.form["quantity"]
        desc = request.form["description"]

        cur.execute("""
            UPDATE Product
            SET PName=%s, PCategory=%s, UnitPrice=%s, Quantity=%s, PDescription=%s
            WHERE PID=%s
        """, (name, category, price, qty, desc, pid))

        conn.commit()
        conn.close()

        flash("Product updated!", "success")
        return redirect(url_for("inventory_list"))

    conn.close()
    return render_template("edit-product.html", product=product)


@app.route("/delete-product/<int:pid>")
def delete_product(pid):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM Product WHERE PID=%s", (pid,))
    conn.commit()
    conn.close()

    flash("Product deleted.", "danger")
    return redirect(url_for("inventory_list"))


# ---------------------------------------------------------
# AI INVENTORY
# ---------------------------------------------------------
@app.route("/ai-inventory.html", methods=["GET", "POST"])
def ai_inventory():
    response = ""

    if request.method == "POST":
        user_msg = request.form.get("message")

        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT PName, Quantity, UnitPrice FROM Product WHERE ActiveFlag = 1")
        products = cur.fetchall()
        conn.close()

        # CORRECT FIX — dict indexing
        inventory_text = "\n".join(
            f"{p['PName']} | Qty: {p['Quantity']} | Price: {p['UnitPrice']}"
            for p in products
        )

        prompt = f"""
You are an inventory assistant for a coffee shop.

Inventory:
{inventory_text}

User question:
{user_msg}
"""

        try:
            ai = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You analyze business inventory."},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=150,
            )

            response = ai.choices[0].message.content

        except Exception as e:
            import traceback
            traceback.print_exc()

    return render_template("ai-inventory.html", response=response)


# ---------------------------------------------------------
# SIMPLE INVENTORY ANALYTICS
# ---------------------------------------------------------
@app.route("/inventory-analytics.html")
def inventory_analytics():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT PName, Quantity FROM Product WHERE ActiveFlag = 1")
    rows = cur.fetchall()
    conn.close()

    chart_data = [{"label": r["PName"], "value": r["Quantity"]} for r in rows]

    return render_template("inventory-analytics.html", chart_data=chart_data)


# ---------------------------------------------------------
# DB TEST
# ---------------------------------------------------------
@app.route("/dbtest")
def dbtest():
    try:
        conn = get_db()
        conn.close()
        return "Database connection successful!"
    except Exception as e:
        return f"DB ERROR: {e}"
